
# dotted chart presentors
## static presentors
from .static.dotted import StaticDottedChartPresentor