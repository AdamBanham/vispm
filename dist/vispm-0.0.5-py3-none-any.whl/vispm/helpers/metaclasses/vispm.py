

class Presentor():
    """
    Dummy meta class for any presentor in vispm library.
    """